# Lesson plan
  
---

```
.box {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 20px;
}

.box div {
  background-color: lightcoral;
  border: solid red 1px;
  width: 200px;
  height: 80px;
  display: flex;
  justify-content: center;
  align-items: center;
}
```